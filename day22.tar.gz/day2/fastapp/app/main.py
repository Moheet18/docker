from fastapi import FastAPI
import show

app= FastAPI()
@app.get("/home")
def home():
    return {"message","welcome Home"}

@app.get("/show")
def show():
    show.show()