from fastapi import FastAPI

app= FastAPI()
@app.get("/show2")
def show():
    return {"message","welcome showcase"}